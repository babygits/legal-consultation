# Legal Consultation System

Frontend: Vue 3 + Vite
Backend: Node.js + Express + MySQL
